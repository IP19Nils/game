<?php

if (isset($_POST["SignUp"])) {
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $gmail = $_POST['gmail'];
    $username = $_POST['username'];
    $passwd = $_POST['passwd'];
    $hashPass = password_hash($passwd, PASSWORD_DEFAULT);


    $sql = "SELECT * FROM Lietotaji WHERE username='$username' OR gmail='$gmail'";
    $result = select($sql, $conn);
    if ($result) {
        $userExistMsg = "User with that gmail or username alerady exist";
    } else {
        $sql = "INSERT INTO Lietotaji(`name`, surname, gmail, username, passwd)
    VALUES ('$name', '$surname', '$gmail', '$username', '$hashPass')";

        $text = insert($sql, $conn);
        if ($text === TRUE) {
            $last_id = $conn->insert_id;
            $sql = "INSERT INTO Maci(`Nauda`, LietotajaID, MaciV, MaciU, MaciZ) VALUE ('1000', '$last_id', '0', '0', '0')";
            if(insert($sql, $conn)===TRUE) {  
                $SingUpMsg = "Veiksmigi izveidots lietotajs.";
            } else {
                $SingUpMsg = "Kluda! Neizdavas izveidot.";
            }
        } else {
            $SingUpMsg = "Kluda! Neizdavas izveidot.";
        }
    }
}