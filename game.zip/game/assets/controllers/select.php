<?php

function login($conn)
{
    if (isset($_POST['LoginSubmit'])) {
        $username = $_POST['username'];
        $passwd = $_POST['passwd'];
        $sql = "SELECT * FROM Lietotaji WHERE username='$username'";
        $result = select($sql, $conn);
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $usernameRow = $row['username'];
                $passwdRow = $row['passwd'];
                if ($username == $usernameRow && password_verify($passwd, $row['passwd'])) {
                    $_SESSION['id'] = $row['id'];
                    $_SESSION['logedIn'] = TRUE;
                    header('Location: menu.php');
                } else {
                    echo "Parole vai lietotaj vārds ir ievadīts nepareizi";
                }
            }
        } else {
            echo "Šāds lietotājs neksistē";
        }
    }
}
function matchData($conn)
{
    $userid = $_SESSION['id'];
    $sql = "SELECT * FROM Maci WHERE LietotajaID='$userid'";
    $result = select($sql, $conn);
    while ($row = $result->fetch_assoc()) {
        echo "
<div class='profile-box'>
<div class='row'>
<div class='w20'>

</div>
<div class='w80'>
<p>" . "Nauda: " . $row['Nauda'] . "</p>
<p>" . "Mači: " . $row['MaciV'] . "</p>
<p>" . "Uzvaras: " . $row['MaciU'] . "</p>
<p>" . "Zaudes: " . $row['MaciZ'] . "</p>
</div>
</div>
</div>
";
    }
}
