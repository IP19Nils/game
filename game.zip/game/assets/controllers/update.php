<?php

if (isset($_POST['ForgotPass'])) {
    $Gmail = $_POST['Gmail'];
    $Username = $_POST['Username'];
    $NewPassword =  $_POST['NewPassword'];
    $hashPass = password_hash($NewPassword, PASSWORD_DEFAULT);

    $sql = "UPDATE Lietotaji SET passwd='$hashPass' WHERE gmail='$Gmail' AND username='$Username'";

    $textUpd = insert($sql, $conn);
    if ($textUpd === TRUE) {
        $PassMsg = "Parole tika veiksmigi nomainita";
    } else {
        $PassMsg = "Kluda! Neizdavas nomainit parole.";
    }
}