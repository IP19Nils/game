window.onload = function () {
    giveCards();
}

let values = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
let symbol = ["C", "D", "H", "S"];
let deck = [];
let playerDeck = [];
let enamyDeck = [];
let randomCard = [];
let turn = true;
//create a deck
for (let i = 0; i < 4; i++) {
    for (let x = 0; x < 13; x++) {
        deck.push(values[x] + "-" + symbol[i]);
    }
}


//shuffle a deck
for (let i = 0; i < deck.length; i++) {
    let x = Math.floor(Math.random() * deck.length);
    let temp = deck[i];
    deck[i] = deck[x];
    deck[x] = temp;
}

//print out in console
console.log(deck);


//give card to player and enamy
function giveCards() {

    //create trupju tuzi
    for (let i = 0; i < 1; i++) {
        let cardImg = document.createElement("img");
        let card = deck.pop();
        cardImg.src = "assets/cardimg/" + card + ".png";
        cardImg.id = "maste";
        document.getElementById("w20").append(cardImg);
        randomCard.push(card);
    }
    console.log(randomCard);

    //create player deck
    for (let i = 0; i < 6; i++) {
        let cardImg = document.createElement("img");
        let card = deck.pop();
        cardImg.src = "assets/cardimg/" + card + ".png";
        cardImg.id = "card-InHands";
        cardImg.dataset.value = card;
        document.getElementById("player-cards").append(cardImg);
        playerDeck.push(card);
    }


    //print player card
    console.log(playerDeck);
    console.log("speletaja karsu daudzums " + playerDeck.length);

    let equal = getEquals(playerDeck);
    console.log(equal);


    //drop card on table
    let cards = document.querySelectorAll("#card-InHands");
    let table = document.getElementById("placed-cards");
    for (i of cards) {
        i.addEventListener('click',
            function () {
                if (turn === true) {
                    table.append(this);
                
                    for (let j = 0; j < playerDeck.length; j++) {
                        if (playerDeck[j] == this.dataset.value) {
                            playerDeck.splice(j, 1);
                        }
                    }
                    console.log(this.dataset.value);
                    console.log(playerDeck);
                    turn = false;
                } else {
                    return;
                }
            });
    }
    console.log(turn);
    //end turn
    let endturn = document.getElementById("endturn");
    endturn.addEventListener('click',
        function () {
            turn = false;
            console.log(turn);
        });

    // // if cards in hands is less than 6 automatically add more cards
    if (playerDeck.length < 6) {
        for (let i = 0; i < (6 - playerDeck.length); i++) {
            let cardImg = document.createElement("img");
            let card = deck.pop();
            cardImg.src = "assets/cardimg/" + card + ".png";
            cardImg.id = "card-InHands";
            document.getElementById("player-cards").append(cardImg);
            playerDeck.push(card);
            console.log(playerDeck);
        }
    } else {
        console.log("lenght=>6");
    }


    // create enamy deack
    for (let i = 0; i < 6; i++) {
        let cardImg = document.createElement("img");
        let card = deck.pop();
        cardImg.src = "assets/cardimg/" + card + ".png";
        cardImg.id = "enamy-look";
        document.getElementById("enamy-cards").append(cardImg);
        enamyDeck.push(card);
    }

    //print enamy cards
    console.log('pretinieka kartis ' + enamyDeck);
    console.log("pretinieka karšu daudzums " + enamyDeck.length);

    if (enamyDeck.length < 6) {
        for (let i = 0; i < (6 - enamyDeck.length); i++) {
            let cardImg = document.createElement("img");
            let card = deck.pop();
            cardImg.src = "assets/cardimg/" + card + ".png";
            cardImg.id = "enamy-look";
            document.getElementById("enamy-cards").append(cardImg);
        }
    }
    // // if cards in hands is less than 6 automatically add more cards
    if (enamyDeck.length < 6) {
        for (let i = 0; i < (6 - enamyDeck.length); i++) {
            let cardImg = document.createElement("img");
            let card = deck.pop();
            cardImg.src = "assets/cardimg/" + card + ".png";
            cardImg.id = "enamy-look";
            document.getElementById("enamy-cards").append(cardImg);
            enamyDeck.push(card);
            console.log(enamyDeck);
        }
    } else {
        console.log("lenght=>6");
    }
    //drop card on table
    let enamyCards = document.querySelectorAll("#enamy-look");
    let enamyTable = document.getElementById("placed-cards");
    for (i of enamyCards) {
        i.addEventListener('click',
            function () {
                enamyTable.append(this);
            });
    }

}

//fuction for geting equal cards
function getEquals(arr) {
    let arrPos = 0;
    let eq = [];

    for (let i = 0; i < arr.length; i++) {
        let index = 0;
        for (let j = 0; j < arr.length; j++) {
            if (arr[i].charAt(0) == arr[j].charAt(0)) {
                index++;
                if (index == 2) {
                    eq[arrPos] = arr[i];
                    arrPos++;
                }
            }
        }
    }

    return eq;
}
