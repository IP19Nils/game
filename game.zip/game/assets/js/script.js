function myFunction() {

    var x = document.getElementById("login");
    if (x.style.display === "block") {
    btn.textContent = 'Login';
    x.style.display = "none";
    } else {
    btn.textContent = 'Registration';
    x.style.display = "block";
    }
   
    var y = document.getElementById("registr");
    if (y.style.display === "none") {
    btn.textContent = 'Login';
    y.style.display = "block";
    } else {
    btn.textContent = 'Registration';
    y.style.display = "none";
    }

    var i = document.getElementById("forgotPass");
    if (i.style.display === "none") {
    btn.textContent = 'Login';
    i.style.display = "block";
    } else {
    btn.textContent = 'Registration';
    i.style.display = "none";
    }

   }